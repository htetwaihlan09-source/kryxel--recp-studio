import os
import uuid
from pathlib import Path
from typing import Optional

from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

UPLOAD_DIR = Path(os.getenv("UPLOAD_DIR", "/app/uploads"))
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
MAX_UPLOAD_MB = int(os.getenv("MAX_UPLOAD_MB", "300"))
ALLOWED_EXTENSIONS = {".mp4", ".mov", ".mkv", ".webm", ".mp3", ".wav", ".m4a"}

app = FastAPI(title="Kryxel Recap API", version="0.1.0")
origins = [x.strip() for x in os.getenv("CORS_ORIGINS", "http://localhost:3000").split(",") if x.strip()]
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)

class RecapRequest(BaseModel):
    title: str = Field(min_length=1, max_length=200)
    notes: str = Field(default="", max_length=12000)
    language: str = Field(default="Burmese", max_length=40)
    tone: str = Field(default="cinematic", max_length=40)
    length: str = Field(default="medium", max_length=30)

class RecapResponse(BaseModel):
    title: str
    language: str
    script: str
    disclaimer: str

@app.get("/health")
def health():
    return {"ok": True, "service": "Kryxel Recap API"}

@app.post("/api/upload")
async def upload_video(file: UploadFile = File(...)):
    suffix = Path(file.filename or "").suffix.lower()
    if suffix not in ALLOWED_EXTENSIONS:
        raise HTTPException(400, "Unsupported file type. Use MP4, MOV, MKV, WEBM, MP3, WAV, or M4A.")
    data = await file.read()
    if not data:
        raise HTTPException(400, "The uploaded file is empty.")
    if len(data) > MAX_UPLOAD_MB * 1024 * 1024:
        raise HTTPException(413, f"File exceeds the {MAX_UPLOAD_MB} MB limit.")
    safe_name = f"{uuid.uuid4().hex}{suffix}"
    path = UPLOAD_DIR / safe_name
    path.write_bytes(data)
    return {"upload_id": safe_name, "filename": file.filename, "bytes": len(data),
            "message": "Upload received. Full video analysis pipeline must be configured separately."}

@app.post("/api/recap", response_model=RecapResponse)
def generate_recap(body: RecapRequest):
    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        return RecapResponse(
            title=body.title,
            language=body.language,
            script=(
                f"[DEMO — add OPENAI_API_KEY to enable AI]\n\n"
                f"Title: {body.title}\nTone: {body.tone}; target length: {body.length}.\n\n"
                f"Create a recap using only the source notes below. Do not invent scenes or plot details. "
                f"If the notes are incomplete, state uncertainty.\n\nSource notes:\n{body.notes or '(No notes supplied yet)'}"
            ),
            disclaimer="Demo response. Add an API key to enable model-generated scripts."
        )
    try:
        from openai import OpenAI
        client = OpenAI(api_key=api_key)
        prompt = f"""Write a narration script for an original movie recap.
Language: {body.language}
Tone: {body.tone}
Length: {body.length}
Title: {body.title}
Source notes/transcript provided by the user:
{body.notes or "(No notes supplied)"}

Rules:
- Base claims only on supplied notes; do not invent plot events.
- If the notes are insufficient, clearly say so and ask for more source material.
- Do not reproduce long copyrighted dialogue or provide a scene-by-scene substitute for the original movie.
- Write natural narration, with a concise hook, coherent transitions, and a short closing.
"""
        result = client.chat.completions.create(
            model=os.getenv("OPENAI_MODEL", "gpt-4.1-mini"),
            messages=[
                {"role": "system", "content": "You are a careful movie-recap script editor."},
                {"role": "user", "content": prompt},
            ],
            temperature=0.7,
        )
        script = result.choices[0].message.content or "No script returned."
        return RecapResponse(title=body.title, language=body.language, script=script,
                             disclaimer="AI-generated draft. Review facts, rights, and platform rules before publishing.")
    except Exception as exc:
        raise HTTPException(502, f"AI provider error: {type(exc).__name__}. Check server logs and API settings.") from exc
