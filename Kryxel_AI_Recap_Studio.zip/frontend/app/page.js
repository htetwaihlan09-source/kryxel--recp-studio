"use client";

import { useState } from "react";

const API = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";

export default function Home() {
  const [title, setTitle] = useState("");
  const [notes, setNotes] = useState("");
  const [language, setLanguage] = useState("Burmese");
  const [tone, setTone] = useState("cinematic");
  const [length, setLength] = useState("medium");
  const [script, setScript] = useState("");
  const [notice, setNotice] = useState("");
  const [busy, setBusy] = useState(false);
  const [file, setFile] = useState(null);

  async function createRecap(e) {
    e.preventDefault();
    setBusy(true); setNotice("Generating your draft…"); setScript("");
    try {
      const res = await fetch(`${API}/api/recap`, {
        method: "POST", headers: {"Content-Type": "application/json"},
        body: JSON.stringify({title, notes, language, tone, length})
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.detail || "Request failed");
      setScript(data.script);
      setNotice(data.disclaimer);
    } catch (err) {
      setNotice(`Could not reach the API: ${err.message}. Check that the backend is running.`);
    } finally { setBusy(false); }
  }

  async function upload() {
    if (!file) { setNotice("Choose a video or audio file first."); return; }
    const form = new FormData(); form.append("file", file);
    setNotice("Uploading…");
    try {
      const res = await fetch(`${API}/api/upload`, {method:"POST", body:form});
      const data = await res.json();
      if (!res.ok) throw new Error(data.detail || "Upload failed");
      setNotice(`Upload received: ${data.filename}. ${data.message}`);
    } catch (err) { setNotice(`Upload error: ${err.message}`); }
  }

  return <main className="shell">
    <nav className="nav"><div className="brandMark">K</div><div><b>Kryxel</b><span> RECAP STUDIO</span></div><div className="navRight">AI STORY WORKSPACE</div></nav>
    <section className="hero">
      <div className="eyebrow"><i/> AI-POWERED STORYTELLING</div>
      <h1>Every movie has<br/><em>a story worth telling.</em></h1>
      <p className="lead">Build cinematic recap scripts from your notes, transcripts, and source material — in Burmese or your preferred language.</p>
      <div className="pills"><span>✦ AI Script Drafts</span><span>◉ Multi-language</span><span>▤ Upload Workspace</span></div>
    </section>

    <section className="workspace">
      <div className="sectionHead"><div><div className="eyebrow">YOUR WORKSPACE</div><h2>Create a recap</h2></div><span className="status">● READY</span></div>
      <form onSubmit={createRecap}>
        <label>Movie / project title<input required maxLength="200" value={title} onChange={e=>setTitle(e.target.value)} placeholder="Enter a movie or project title"/></label>
        <div className="twoCols">
          <label>Output language<select value={language} onChange={e=>setLanguage(e.target.value)}><option>Burmese</option><option>English</option><option>Thai</option><option>Hindi</option><option>Japanese</option></select></label>
          <label>Narration tone<select value={tone} onChange={e=>setTone(e.target.value)}><option value="cinematic">Cinematic</option><option value="dramatic">Dramatic</option><option value="friendly">Friendly</option><option value="documentary">Documentary</option></select></label>
        </div>
        <label>Recap length<select value={length} onChange={e=>setLength(e.target.value)}><option value="short">Short (about 1 minute)</option><option value="medium">Medium (about 3–5 minutes)</option><option value="long">Long (about 8–10 minutes)</option></select></label>
        <label>Source notes / transcript<textarea rows="7" value={notes} onChange={e=>setNotes(e.target.value)} placeholder="Paste your own synopsis, notes, or transcript excerpt. The AI should not invent details that aren't in the source." /></label>
        <button className="primary" disabled={busy}>{busy ? "Working…" : "✦ Generate recap script"}</button>
      </form>
      <div className="uploadBox"><div className="uploadIcon">↑</div><div className="uploadText"><b>Upload source media</b><span>MP4, MOV, MKV, WEBM, MP3, WAV, M4A · max configured size</span><input type="file" accept=".mp4,.mov,.mkv,.webm,.mp3,.wav,.m4a" onChange={e=>setFile(e.target.files?.[0] || null)}/></div><button className="secondary" onClick={upload} type="button">Upload file</button></div>
      {notice && <div className="notice">{notice}</div>}
      {script && <section className="output"><div className="sectionHead"><h2>Recap script</h2><button className="secondary" onClick={()=>navigator.clipboard?.writeText(script)}>Copy script</button></div><pre>{script}</pre></section>}
    </section>

    <section className="features"><div><span>01</span><h3>Script studio</h3><p>Draft narration from your own notes and source material.</p></div><div><span>02</span><h3>Language-ready</h3><p>Start with Burmese and expand to more languages.</p></div><div><span>03</span><h3>Built to scale</h3><p>Add voiceover, subtitles, rendering, accounts, and billing next.</p></div></section>
    <footer><b>Kryxel RECAP</b><span>Original scripts. Responsible storytelling.</span></footer>
  </main>;
}
