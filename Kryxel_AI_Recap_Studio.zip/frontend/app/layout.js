import "./globals.css";

export const metadata = {
  title: "Kryxel | AI Movie Recap Studio",
  description: "Turn your notes into cinematic recap scripts with Kryxel."
};

export default function RootLayout({ children }) {
  return <html lang="en"><body>{children}</body></html>;
}
