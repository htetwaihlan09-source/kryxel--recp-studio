# Kryxel AI Movie Recap Studio

A deployable full-stack starter for an AI movie-recap workflow. Includes:
- Next.js App Router frontend
- FastAPI backend
- OpenAI-compatible script generation (optional, configured by env vars)
- Upload endpoint with size/type checks
- FFmpeg integration instructions for later video rendering
- Docker Compose for local development

## Important scope
This is a working starter, not a finished hosted service. It does not automatically understand an entire movie from a large upload yet: production-grade video understanding requires chunking, audio transcription, frame sampling, queues, and object storage. Never upload or recap movies you do not have rights to use.

## Run locally
1. Install Docker Desktop.
2. Copy `.env.example` to `.env` and add your API key if you want AI generation.
3. Run `docker compose up --build`.
4. Open http://localhost:3000 (frontend) and http://localhost:8000/docs (API docs).

Without an API key, the backend returns a clearly labeled demo recap.

## Deploy publicly
- Frontend: deploy `frontend/` to Vercel; set `NEXT_PUBLIC_API_URL` to your deployed backend URL.
- Backend: deploy `backend/` to Render, Railway, Fly.io, or a VPS using the included Dockerfile.
- Set backend environment variables: `OPENAI_API_KEY`, `OPENAI_MODEL`, `CORS_ORIGINS`, `MAX_UPLOAD_MB`.
- Set `CORS_ORIGINS` to the exact deployed frontend origin, e.g. `https://your-app.vercel.app`.
- Do not put API keys in `NEXT_PUBLIC_*` variables.
- For public uploads, use private object storage (S3/R2/Supabase Storage), signed URLs, authentication, rate limiting, malware scanning, and retention/deletion policies before opening access to everyone.

## Current limitations
- Upload endpoint stores files in a local temporary folder. On serverless hosting this is not durable; use object storage for production.
- No user accounts, payments, background job queue, or actual final video rendering are included yet.
- For production, add authentication, usage quotas, billing, durable storage, and a worker queue before accepting paid customers.
